<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Page</title>
</head>
<body>

    <form action="<?php echo e(Route('auth.save')); ?>" method="post">
        <?php if(Session::get("success")): ?>
        <?php echo e(Session::get("success")); ?>

    <?php endif; ?>
    <?php if(Session::get("fail")): ?>
        <?php echo e(Session::get("fail")); ?>

    <?php endif; ?>
        <?php echo csrf_field(); ?>

        <input type="text" name="name" placeholder="Name"><br>
        <input type="text" name="email" placeholder="Email"><br>
        <input type="text" name="password" placeholder="Password"><br>
        <input type="submit">
    </form>
</body>
</html><?php /**PATH C:\Users\MNIC\Desktop\Laravel\Ticket\resources\views/auth/register.blade.php ENDPATH**/ ?>