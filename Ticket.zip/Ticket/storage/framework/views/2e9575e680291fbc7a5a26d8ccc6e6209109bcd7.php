<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('auth.logout')); ?>">Logout</a><br>
        Bugs List
        <table>
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
            </tr>
            <?php if(isset($bug_data)): ?>
            <?php if($bug_data): ?>
            <?php $__currentLoopData = $bug_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->pub); ?></td>
                <td><?php echo e($item->descr); ?></td>
                <td><?php echo e($item->summary); ?></td>
                <?php if( $item->resolve == Null): ?>
                <td>Undefined</td>
        <?php endif; ?>
        <?php if( $item->resolve  == "0"): ?>
            <td>Declined</td>
        <?php endif; ?>
        <?php if( $item->resolve  == "1"): ?>
            <td>Accepted</td>
        <?php endif; ?>
                <td><?php echo e($item->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php else: ?>
                No data
            <?php endif; ?>
        </table>
        <br>
        Test Case Table
        <table style="border-type:solid;border:1px;">
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
            </tr>
            <?php if(isset($test_data)): ?>
            <?php if($test_data): ?>
            <?php $__currentLoopData = $test_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->pub); ?></td>
                <td><?php echo e($item->descr); ?></td>
                <td><?php echo e($item->summary); ?></td>
                <?php if( $item->resolve == Null): ?>
                <td>Undefined</td>
        <?php endif; ?>
        <?php if( $item->resolve  == "0"): ?>
            <td>Declined</td>
        <?php endif; ?>
        <?php if( $item->resolve  == "1"): ?>
            <td>Accepted</td>
        <?php endif; ?>
                <td><?php echo e($item->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php else: ?>
                No data
            <?php endif; ?>
            
        </table>

<br>
    Feature Case Table <br>
    <form action="" method="GET">
        <input type="text" name="add" value="true" hidden>
        <input type="text" name="type" value="fc" hidden>
        <button>Add Feature Request</button><br>
    </form>
    <table style="border-type:solid;border:1px;">
        <tr>
            <th>Case ID</th>
            <th>Publisher</th>
            <th>Descriptions</th>
            <th>Summary</th>
            <th>Status</th>
            <th>Created at</th>
            <th>Last Update</th>
            <th>Actions</th>
        </tr>
        <?php if(isset($fa_data)): ?>
        <?php if($fa_data): ?>
        <?php $__currentLoopData = $fa_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($items->id); ?></td>
            <td><?php echo e($items->pub); ?></td>
            <td><?php echo e($items->descr); ?></td>
            <td><?php echo e($items->summary); ?></td>
            <?php if( $items->resolve == Null): ?>
            <td>Undefined</td>
    <?php endif; ?>
    <?php if( $items->resolve  == "0"): ?>
        <td>Declined</td>
    <?php endif; ?>
    <?php if( $items->resolve  == "1"): ?>
        <td>Accepted</td>
    <?php endif; ?>
            <td><?php echo e($items->created_at); ?></td>
            <td><?php echo e($item->updated_at); ?></td>
            <form action="" method="GET">
                <td><input type="submit" value="Edit"></td>
                <input type="text" value="fc" name="destination" hidden>
                <input name="num" value="<?php echo e($items->id); ?>" hidden>
            </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        No data
        <?php endif; ?>
        <?php endif; ?>   
    </table>
    <br>
    <?php if(isset($edit_test_data)): ?>
        <form action="<?php echo e(Route("page.qa.edit_test")); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="destination" value="<?php echo e($tb_name); ?>" hidden>
            <input type="text" name="id" value="<?php echo e($edit_test_data->id); ?>" hidden>
            <input type="text" name="new_desc" id="" value="<?php echo e($edit_test_data->descr); ?>">
            <input type="text" name="new_summary" id="" value="<?php echo e($edit_test_data->summary); ?>">
            <input type="submit" value="Change">
        </form>
        <form action="<?php echo e(Route('page.qa.del')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="tb" value="<?php echo e($tb_name); ?>" hidden>
            <input type="text" name="id" value="<?php echo e($edit_test_data->id); ?>" hidden>
            <input type="submit" value="Delete">
        </form>
    <?php endif; ?>
        <?php if(Session::get('c')): ?>
        <?php echo e(Session::get('c')); ?>

        <?php endif; ?>
        <br>
        
    <?php if(isset($_GET['add'])): ?>
        <?php if($_GET['add'] == "true"): ?>
        <?php if($_GET['type'] == "fc"): ?>
        Add New Feature Request
        <form action="<?php echo e(Route('page.qa.insert_feature')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <input type="text" name="new_descr" value=""><br>
        <input type="text" name="new_summary" value=""><br>
        <input type="submit">
        </form>
        <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(Session::get('m')): ?>
    <?php echo e(Session::get('m')); ?>

    <?php endif; ?>
    <?php if(Session::get('d')): ?>
    <?php echo e(Session::get('d')); ?>

    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\MNIC\Desktop\Laravel\Ticket\resources\views/pm.blade.php ENDPATH**/ ?>