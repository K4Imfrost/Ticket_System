<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainControl;
use App\Http\Controllers\tablecontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/auth/save',[MainControl::class,'save'])->name("auth.save");
Route::post('/auth/check',[MainControl::class,'check'])->name("auth.check");
Route::get("/auth/logout",[MainControl::class,"logout"])->name("auth.logout");
Route::post("/edit_test",[tablecontroller::class,"edit_test"])->name("page.qa.edit_test");
Route::get("/add_test",[tablecontroller::class,"add_test"])->name("page.qa.add_test");
Route::post("/insert_test",[tablecontroller::class,"add_test"])->name("page.qa.insert_test");
Route::post("/insert_bug",[tablecontroller::class,"add_bug"])->name("page.qa.insert_bug");
Route::post("/insert_request",[tablecontroller::class,"add_feature"])->name("page.qa.insert_feature");
Route::post("/resolve",[tablecontroller::class,"resolve"])->name("page.qa.resolve");
Route::post("/del",[tablecontroller::class,"del"])->name("page.qa.del");

Route::group(["middleware"=>['authcheck']],function(){
    Route::get("/auth/register",[MainControl::class,"regpage"])->name("auth.reg");
    Route::get("/auth/login",[MainControl::class,'log'])->name("auth.login");
    Route::get("/rd",[tablecontroller::class,"dashboard"]);
    Route::get("/pm",[tablecontroller::class,"dashboard"]);
    Route::get("/qa",[tablecontroller::class,"dashboard"])->name("page.qa");
    Route::get("/admin",[tablecontroller::class,"dashboard"]);

});
