<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="{{ route('auth.logout') }}">Logout</a><br>
        Bugs List
        <table>
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Actions</th>
            </tr>
            @if(isset($bug_data))
            @if ($bug_data)
            @foreach ($bug_data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->pub}}</td>
                <td>{{ $item->descr}}</td>
                <td>{{$item->summary}}</td>
                @if ( $item->resolve == Null)
                <td>Undefined</td>
        @endif
        @if ( $item->resolve  == "0")
            <td>Declined</td>
        @endif
        @if ( $item->resolve  == "1")
            <td>Accepted</td>
        @endif
                <td>{{$item->created_at}}</td>
                <form action="{{Route('page.qa.resolve')}}" method="POST">
                    @csrf
                <input type="text" value="bug" name="tb" hidden>
                <input name="id" value="{{$item->id}}" hidden>
                <td><input type="submit" value="Resolve"></td>
                </form>
                </tr>
            @endforeach
            @endif
            @else
                No data
            @endif
        </table>
        @if (Session::get("r1")){
            {{ Session::get("r1") }}
        }
        @endif
        <br>
        Test Case Table
        <table style="border-type:solid;border:1px;">
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
            </tr>
            @if(isset($test_data))
            @if ($test_data)
            @foreach ($test_data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->pub}}</td>
                <td>{{ $item->descr}}</td>
                <td>{{$item->summary}}</td>
                @if ( $item->resolve == Null)
                <td>Undefined</td>
        @endif
        @if ( $item->resolve  == "0")
            <td>Declined</td>
        @endif
        @if ( $item->resolve  == "1")
            <td>Accepted</td>
        @endif
                <td>{{$item->created_at}}</td>
                </tr>
            @endforeach
            @endif
            @else
                No data
            @endif
            
        </table>
<br>
    Feature Case Table <br>
    <table style="border-type:solid;border:1px;">
        <tr>
            <th>Case ID</th>
            <th>Publisher</th>
            <th>Descriptions</th>
            <th>Summary</th>
            <th>Status</th>
            <th>Created at</th>
            <th>Actions</th>
        </tr>
        @if(isset($fa_data))
        @if ($fa_data)
        @foreach ($fa_data as $items)
        <tr>
            <td>{{ $items->id }}</td>
            <td>{{ $items->pub}}</td>
            <td>{{ $items->descr}}</td>
            <td>{{ $items->summary }}</td>
            @if ( $items->resolve == Null)
            <td>Undefined</td>
    @endif
    @if ( $items->resolve  == "0")
        <td>Declined</td>
    @endif
    @if ( $items->resolve  == "1")
        <td>Accepted</td>
    @endif
            <td>{{ $items->created_at }}</td>
            <form action="{{Route('page.qa.resolve')}}" method="POST">
                @csrf
            <input type="text" value="fc" name="tb" hidden>
            <input name="id" value="{{$items->id}}" hidden>
            <td><input type="submit" value="Resolve"></td>
            </form>
            </tr>
        @endforeach
        @else
        No data
        @endif
        @endif   
    </table>
    @if (Session::get("r3")){
        {{ Session::get("r3") }}
    }
    @endif
</body>
</html>