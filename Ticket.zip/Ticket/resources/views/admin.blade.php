<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="{{ route('auth.logout') }}">Logout</a><br>
        Add Account
        <form action="{{ Route("auth.save") }}" method="POST">
            @csrf
            <input type="text" name="name" placeholder="Name..">
            <input type="text" name="email" placeholder="email..">
            <input type="text" name="password" placeholder="password..">
            <select name="job_type">
                <option value="qa">QA</option>
                <option value="rd">RD</option>
                <option value="pm">PM</option>
            </select>
            <input type="submit" value="add">
        </form>
        @if(Session::get('success'))
        {{Session::get('successs')}}
        @endif
        @if(Session::get('fail'))
        {{Session::get('fail')}}
        @endif
        <br>
        Bugs List
        <form action="" method="GET">
            <input type="text" name="add" value="true" hidden>
            <input type="text" name="type" value="bc" hidden>
            <button>Add Bug Case</button><br>
        </form>
        <table>
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Last Update</th>
                <th>Actions</th>
            </tr>
            @if(isset($bug_data))
            @if ($bug_data)
            @foreach ($bug_data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->pub}}</td>
                <td>{{ $item->descr}}</td>
                <td>{{$item->summary}}</td>
                @if ( $item->resolve == Null)
                        <td>Undefined</td>
                @endif
                @if ( $item->resolve  == "0")
                    <td>Declined</td>
                @endif
                @if ( $item->resolve  == "1")
                    <td>Accepted</td>
                @endif
                <td>{{$item->created_at}}</td>
                <td>{{$item->updated_at}}</td>
                <form action="" method="GET">
                <input type="text" value="bc" name="destination" hidden>
                <input name="num" value="{{$item->id}}" hidden>
                <td><input type="submit" value="Edit">              
                </form>  
                <form action="{{Route('page.qa.resolve')}}" method="POST">
                    @csrf
                <input type="text" value="bug" name="tb" hidden>
                <input name="id" value="{{$item->id}}" hidden>
                <td><input type="submit" value="Resolve"></td>
                </form></td>
                </tr>
            @endforeach
            @endif
            @else
                No data
            @endif
        </table>
        @if (Session::get("r1"))
        {{ Session::get("r1") }}
    @endif
        <br>
        Test Case Table
        <form action="" method="GET">
            <input type="text" name="add" value="true" hidden>
            <input type="text" name="type" value="tc" hidden>
            <button>Add Test Case</button><br>
        </form>
        <table style="border-type:solid;border:1px;">
            <tr>
                <th>Case ID</th>
                <th>Publisher</th>
                <th>Descriptions</th>
                <th>Summary</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Last Update</th>
                <th>Actions</th>
            </tr>
            @if(isset($test_data))
            @if ($test_data)
            @foreach ($test_data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->pub}}</td>
                <td>{{ $item->descr}}</td>
                <td>{{$item->summary}}</td>
                @if ( $item->resolve == Null)
                <td>Undefined</td>
                @endif
                @if ( $item->resolve  == "0")
                <td>Declined</td>
                @endif
                @if ( $item->resolve  == "1")
                <td>Accepted</td>
                @endif
                <td>{{$item->created_at}}</td>
                <td>{{$item->updated_at}}</td>
                <form action="" method="GET">
                <input type="text" value="tc" name="destination" hidden>
                <input name="num" value="{{$item->id}}" hidden>
                <td><input type="submit" value="Edit">
                </form>
                <form action="{{Route('page.qa.resolve')}}" method="POST">
                    @csrf
                <input type="text" value="tc" name="tb" hidden>
                <input name="id" value="{{$item->id}}" hidden>
                <td><input type="submit" value="Resolve"></td>
                </form></td>
                
                </tr>
            @endforeach
            @endif
            @else
                No data
            @endif
            
        </table>
        @if (Session::get("r2"))
            {{ Session::get("r2") }}
        @endif
<br>
    Feature Case Table <br>
    <form action="" method="GET">
        <input type="text" name="add" value="true" hidden>
        <input type="text" name="type" value="fc" hidden>
        <button>Add Bug Case</button><br>
    </form>
    <table style="border-type:solid;border:1px;">
        <tr>
            <th>Case ID</th>
            <th>Publisher</th>
            <th>Descriptions</th>
            <th>Summary</th>
            <th>Status</th>
            <th>Created at</th>
            <th>Last Update</th>
            <th>Actions</th>
        </tr>
        @if(isset($fa_data))
        @if ($fa_data)
        @foreach ($fa_data as $items)
        <tr>
            <td>{{ $items->id }}</td>
            <td>{{ $items->pub}}</td>
            <td>{{ $items->descr}}</td>
            <td>{{ $items->summary }}</td>
            @if ( $items->resolve == Null)
            <td>Undefined</td>
            @endif
            @if ( $items->resolve  == "0")
            <td>Declined</td>
            @endif
            @if ( $items->resolve  == "1")
            <td>Accepted</td>
            @endif
            <td>{{ $items->created_at }}</td>
            <td>{{$items->updated_at}}</td>
            <form action="" method="GET">
                <input type="text" value="fc" name="destination" hidden>
                <input name="num" value="{{$items->id}}" hidden>
                <td><input type="submit" value="Edit">
                </form>
                <form action="{{Route('page.qa.resolve')}}" method="POST">
                    @csrf
                <input type="text" value="fc" name="tb" hidden>
                <input name="id" value="{{$items->id}}" hidden>
                <td><input type="submit" value="Resolve"></td>
                </form></td>
            </tr>
        @endforeach
        @else
        No data
        @endif
        @endif   
    </table>
    @if (Session::get("r3"))
    {{ Session::get("r3") }}
@endif
    <br>
    @if (isset($edit_test_data))
        <form action="{{ Route("page.qa.edit_test") }}" method="POST">
            @csrf
            <input type="text" name="destination" value="{{ $tb_name }}" hidden>
            <input type="text" name="id" value="{{ $edit_test_data->id }}" hidden>
            <input type="text" name="new_desc" id="" value="{{$edit_test_data->descr}}">
            <input type="text" name="new_summary" id="" value="{{$edit_test_data->summary}}">
            <input type="submit" value="Change">
        </form>
        <form action="{{ Route('page.qa.del') }}" method="post">
            @csrf
            <input type="text" name="tb" value="{{$tb_name}}" hidden>
            <input type="text" name="id" value="{{$edit_test_data->id}}" hidden>
            <input type="submit" value="Delete">
        </form>
    @endif
        @if (Session::get('c'))
        {{Session::get('c')}}
        @endif
        <br>
    @if (isset($_GET['add']))
        @if($_GET['add'] == "true")
        @if($_GET['type'] == "tc")
        Add New Test Case
        <form action="{{ Route('page.qa.insert_test') }}" method="post">
            @csrf
        <input type="text" name="new_descr" value=""><br>
        <input type="text" name="new_summary" value=""><br>
        <input type="submit">
        </form>
        @endif
        @if ($_GET['type'] == "bc")
        Add New Bug Case
        <form action="{{ Route('page.qa.insert_bug') }}" method="post">
            @csrf
        <input type="text" name="new_descr" value=""><br>
        <input type="text" name="new_summary" value=""><br>
        <input type="submit">
        </form>
        @endif
        @if ($_GET['type'] == "fc")
        Add New Feature Request
        <form action="{{ Route('page.qa.insert_feature') }}" method="post">
            @csrf
        <input type="text" name="new_descr" value=""><br>
        <input type="text" name="new_summary" value=""><br>
        <input type="submit">
        </form>
        @endif
        @endif
    @endif
    @if (Session::get('m'))
    {{Session::get('m')}}
    @endif
    @if (Session::get('d'))
    {{Session::get('d')}}
    @endif
</body>
</html>