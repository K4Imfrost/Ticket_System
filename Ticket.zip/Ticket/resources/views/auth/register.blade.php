<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Page</title>
</head>
<body>

    <form action="{{ Route('auth.save')}}" method="post">
        @if(Session::get("success"))
        {{ Session::get("success") }}
    @endif
    @if(Session::get("fail"))
        {{ Session::get("fail") }}
    @endif
        @csrf

        <input type="text" name="name" placeholder="Name"><br>
        <input type="text" name="email" placeholder="Email"><br>
        <input type="text" name="password" placeholder="Password"><br>
        <input type="submit">
    </form>
</body>
</html>