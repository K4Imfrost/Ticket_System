<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::table("admins")->insert([
            "name"=>"qa", 
            "email"=>"qa@test.com",
            "job"=>"qa",
            "password"=>Hash::make("123")
        ]);
        DB::table("admins")->insert([
            "name"=>"rd", 
            "email"=>"rd@test.com",
            "job"=>"rd",
            "password"=>Hash::make("123")
        ]);
        DB::table("admins")->insert([
            "name"=>"pm", 
            "email"=>"pm@test.com",
            "job"=>"pm",
            "password"=>Hash::make("123")
        ]);
        DB::table("admins")->insert([
            "name"=>"admin", 
            "email"=>"admin@test.com",
            "job"=>"admin",
            "password"=>Hash::make("123")
        ]);
        DB::table("test_cases")->insert([
            "descr"=>"test case 1", 
            "summary"=>"test case 1",
            "pub"=>"123",
            "viewed"=>"0",
            "view_by"=>null,
            "resolve"=>null
        ]);
        DB::table("bug_tables")->insert([
            "descr"=>"bug test 1", 
            "summary"=>"bug test 1",
            "pub"=>"123",
            "viewed"=>"0",
            "view_by"=>null,
            "resolve"=>null
        ]);
        DB::table("feature_cases")->insert([
            "descr"=>"feature test 1", 
            "summary"=>"feature test 1",
            "pub"=>"123",
            "viewed"=>"0",
            "view_by"=>null,
            "resolve"=>null
        ]);
    }
}
