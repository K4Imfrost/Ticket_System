<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class authcheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if(!session()->has("Logged") && ($request->path() != "auth/login" && $request->path() != "auth/register")){
            return redirect("auth/login");
        }
        if(session()->has("Logged") && ($request->path() == "auth/login" || $request->path() == "auth/register")){
            return back();
        }
        if(session()->has("Logged") && session()->has("job")){
            if(session("job") != $request->path()){
                    if(session("job") == "qa"){
                        return redirect('qa');
                    }else if(session("job") == "rd"){
                        return redirect('rd');
                    }else if(session("job") == "pm"){
                        return redirect('pm');
                    }else if(session("job") == "admin"){
                        return redirect('admin');
                    }
            }
        }
        return $next($request)->header("Cache-Control","no-cache , no-store, max-age=0 , must-revalidate")
                              ->header("Pragma","no-cache")
                              ->header("Expires","Sat 01 Jan 1990 00:00:00 GMT");
    }
}
