<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\test_case;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
class MainControl extends Controller
{
    function index(Request $r){
        return $r->input();
    }

    function save(Request $s){
        $s->validate(["name"=>"required",
        "email"=>"required|unique:admins|email",
        "password"=>"required",
        "job_type"=>"required"
    ]);
    $admin = new Admin;
    $admin->name =$s->name;
    $admin->email =$s->email;
    $admin->job = $s->job_type;
    $admin->password =hash::make($s->password);
    $save = $admin->save();

    if (!$save){
        return back()->with('success',"Insert successfully");
    }else{
        return back()->with('fail',"Insert unsuccessfully");
    }
    }

    function check(Request $log){
        $log->validate(['email'=>"required","password"=>"required"]);
        $data = Admin::where("email","=",$log->email)->first();
        if (Hash::check($log->password,$data->password)){
            if($data){
                $log->session()->put("Logged",$data->name);
                $log->session()->put("job",$data->job);
                if($data->job =="qa"){
                    return redirect("qa");
                }else if($data->job=="rd"){
                    return redirect("rd");
                }else if($data->job=="pm"){
                    return redirect("pm");
                }else if($data->job=="admin"){
                    return redirect("admin");
                }
            }else{
                return back()->with("fail_message","User not found");
            }
        }else{
            return back()->with("p","password incorrect");
        }
    }
    function logout(){
        if(session()->has("Logged")){
            session()->pull("Logged");
            return redirect("auth/login");
        }
    }
    function dirqa(){
        $da = ["test_data"=>DB::table("test_cases")->orderBy("id","desc")->get()];
        $fa = ["fa_data"=>DB::table("feature_cases")->orderBy("id","desc")->get()];
        $ba = ["bug_data"=>DB::table("bug_tables")->orderBy("id","desc")->get()];
        return view("qa")->with($da)->with($fa)->with($ba);
    }
    function log(){
        return view('auth.login');
    }
    function regpage(){
        return view('auth.register');
    }
}
