<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\bug_table;
use Illuminate\Http\Request;
use App\Models\test_case;

use App\Models\feature_case;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use phpDocumentor\Reflection\Types\Null_;
use Symfony\Component\HttpFoundation\AcceptHeader;

class tablecontroller extends Controller
{
    function dashboard(){
        $da = ["test_data"=>DB::table("test_cases")->orderBy("id","desc")->get()];
        $fa = ["fa_data"=>DB::table("feature_cases")->orderBy("id","desc")->get()];
        $ba = ["bug_data"=>DB::table("bug_tables")->orderBy("id","desc")->get()];
        $des = "";
        if (Session('job')=='qa'){
            $des = "qa";
        }else if (Session('job')=='rd'){
            $des = "rd";
        }else if (Session('job')=='pm'){
            $des = "pm";
        }else if (Session('job')=='admin'){
            $des = "admin";
        }

        if (isset($_GET['num'])){
            $table_name = "";
            if(isset($_GET['destination'])){
                if($_GET['destination'] == "tc"){
                    $table_name = "test_cases";
                }else if ($_GET['destination'] == "fc"){
                    $table_name = "feature_cases";
                }else if ($_GET['destination'] == 'bc'){
                    $table_name = "bug_tables";
                }
            }
            $test_table_data = ['edit_test_data'=>DB::table($table_name)->find($_GET['num'])]; 
            return view($des)->with($da)->with($fa)->with($ba)->with($test_table_data)->with("tb_name",$table_name);
        }
        return view($des)->with($da)->with($fa)->with($ba);
    }


    function edit_test(Request $r){
        if(isset($_POST['id']) && isset($_POST['new_desc']) && isset($_POST['new_summary']) && isset($_POST['destination'])){

            if(DB::table($_POST['destination'])->where("id",$_POST['id'])->update(['descr' => $_POST['new_desc'],'summary'=>$_POST['new_summary']])){
                    return back()->with("c","update successful");
                }else{
                    return back()->with("c","Nothing Changed");
                }
        }else{
            return back()->with("c","failure to recognize parameter");
        }
    }

    function add_feature(Request $r){

        $r->validate(["new_summary"=>"required","new_descr"=>"required"]);
        $add = new feature_case();
        $add->summary = $_POST['new_summary'];
        $add->descr = $_POST['new_descr'];
        $add->pub = session('Logged');
        $add->viewed = "0";
        $t = $add->save();
        if ($t){
            return back()->with("m","added successful");
        }else{
            return back()->with("m","failed to add ");
        }
    }

    function add_test(Request $r){

        $r->validate(["new_summary"=>"required","new_descr"=>"required"]);
        $add = new test_case();
        $add->summary = $_POST['new_summary'];
        $add->descr = $_POST['new_descr'];
        $add->pub = session('Logged');
        $add->viewed = "0";
        $t = $add->save();
        if ($t){
            return back()->with("m","added successful");
        }else{
            return back()->with("m","failed to add ");
        }
    }
    function add_bug(Request $r){

        $r->validate(["new_summary"=>"required","new_descr"=>"required"]);
        $add = new bug_table();
        $add->summary = $_POST['new_summary'];
        $add->descr = $_POST['new_descr'];
        $add->pub = session('Logged');
        $add->viewed = "0";
        $t = $add->save();
        if ($t){
            return back()->with("m","added successful");
        }else{
            return back()->with("m","failed to add ");
        }
    }

    function del(){
        if ($_POST['tb'] && $_POST['id']){
            if(DB::table($_POST['tb'])->delete($_POST['id'])){
                return back()->with("d","delete ID: ".$_POST['id']." From ".$_POST["tb"]." successfully");
            }
        }
    }
    
    function resolve(Request $r){
        // 0 = decline
        // 1 = Acceptted
        // null = unknown
        $s = "";
        $message = "";
        $table = "";
        if($r->tb == "bug"){
            $s = bug_table::where("id","=",$r->id)->first();
            $message = "r1";
            $table = "bug_tables";
        }
        if ($r->tb == "tc"){
            $s = test_case::where("id","=",$r->id)->first();
            $message = "r2";
            $table = "test_cases";
        }
        if ($r->tb == "fc"){
            $s = feature_case::where("id","=",$r->id)->first();
            $message = "r3";
            $table = "feature_cases";
        }

        if ($s){
            if($s->resolve != Null){
                if ($s->resolve == "0"){
                    if(DB::table($table)->where("id",$r->id)->update(["resolve"=>"1"])){
                        return back()->with($message,"Case ID ".$r->id." resolved to Accepted");
                    }
                }else if ($s->resolve == "1"){
                    DB::table($table)->where("id",$r->id)->update(["resolve"=>"0"]);
                    return back()->with($message,"Case ID ".$r->id." resolved to Decline");
                }
            }    
            else{
                DB::table($table)->where("id","=",$r->id)->update(["resolve"=>"1"]);
                return back()->with($message,"Case ID ".$r->id." resolved to Accepted");
            }
        }
    }
}
